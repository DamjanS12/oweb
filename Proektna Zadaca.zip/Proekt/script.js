var x=document.getElementById('login');
		var y=document.getElementById('register');
		var z=document.getElementById('btn');
		function register()
		{
			x.style.left='-400px';
			y.style.left='50px';
			z.style.left='110px';
		}
		function login()
		{
			x.style.left='50px';
			y.style.left='450px';
			z.style.left='0px';
		}


        var modal = document.getElementById('login-form');
        window.onclick = function(event) 
        {
            if (event.target == modal) 
            {
                modal.style.display = "none";
            }
        }



        var slideIndex = 1;
var slideshow = document.getElementsByClassName("picture");
showPic(slideIndex);

function plusPic(n){
  slideIndex += n;
  showPic();
}

function showPic(){
  if (slideIndex > slideshow.length){slideIndex = 1}
  if (slideIndex < 1) {slideIndex = slideshow.length};
  for (var i = 0; i < slideshow.length; i++){
    slideshow[i].style.display = "none";
  }
  slideshow[slideIndex-1].style.display = "block";
}

document.addEventListener('DOMContentLoaded', function () {
    var likeButtons = document.querySelectorAll('.like-btn');

    likeButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var counter = this.nextElementSibling;
            var currentLikes = parseInt(counter.textContent, 10);
            counter.textContent = currentLikes + 1;
        });
    });
});

function buyProduct() {
    alert("Thank you for your purchase.Follow the steps that we sent you on mail!");
}






/*
const header = document.querySelector("header");
window.addEventListener ("scroll", function() {
	header.classList.toggle ("sticky", window.scrollY > 100);
});

let menu = document.querySelector('#menu-icon');
let navlist = document.querySelector('.navlist');

menu.onclick = () => {
	menu.classList.toggle('bx-x');
	navlist.classList.toggle('open');
};

window.onscroll = () => {
	menu.classList.remove('bx-x');
	navlist.classList.remove('open');
};*/